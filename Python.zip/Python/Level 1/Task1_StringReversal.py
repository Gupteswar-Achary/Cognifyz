str = input("Enter a string: ")
reverse = str[::-1]
print('Reversed String is : ', reverse)